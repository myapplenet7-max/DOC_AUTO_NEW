import os
from twilio.rest import Client

TWILIO_ACCOUNT_SID   = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN    = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_WHATSAPP_FROM = os.getenv("TWILIO_WHATSAPP_FROM", "whatsapp:+14155238886")
ADMIN_WHATSAPP       = os.getenv("ADMIN_WHATSAPP_NUMBER")
BULK_ENQUIRY_NUMBER  = os.getenv("ADMIN_WHATSAPP_NUMBER")  # same number for bulk enquiries

def _client():
    if not TWILIO_ACCOUNT_SID or not TWILIO_AUTH_TOKEN:
        raise RuntimeError("Twilio credentials not set.")
    return Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

def notify_admin_new_payment(user_name, user_mobile, amount, credits, payment_id, upi_ref=None):
    ref_line = f"\n📌 UTR: {upi_ref}" if upi_ref else ""
    msg = (
        f"💰 *New Payment Received*\n"
        f"─────────────────\n"
        f"👤 {user_name} ({user_mobile})\n"
        f"💵 Amount: ₹{amount} → {credits} credits{ref_line}\n"
        f"🆔 Payment ID: #{payment_id}\n"
        f"─────────────────\n"
        f"Open admin panel to Approve or Reject."
    )
    _send(ADMIN_WHATSAPP, msg)

def notify_user_payment_approved(user_whatsapp, user_name, amount, credits, new_balance):
    msg = (
        f"✅ *Payment Approved!*\n"
        f"─────────────────\n"
        f"Hi {user_name},\n"
        f"Your payment of ₹{amount} is verified.\n"
        f"🎟️ Credits added: {credits}\n"
        f"💼 Total credits: {new_balance}\n"
        f"─────────────────\n"
        f"You can now process documents on DocAuto."
    )
    _send(f"whatsapp:{user_whatsapp}", msg)

def notify_user_payment_rejected(user_whatsapp, user_name, amount, note=None):
    note_line = f"\n📝 Reason: {note}" if note else ""
    msg = (
        f"❌ *Payment Not Approved*\n"
        f"─────────────────\n"
        f"Hi {user_name},\n"
        f"We could not verify your payment of ₹{amount}.{note_line}\n"
        f"Please resubmit with a clear screenshot."
    )
    _send(f"whatsapp:{user_whatsapp}", msg)

def notify_admin_bulk_enquiry(user_name, user_mobile, message=""):
    msg = (
        f"📦 *Bulk Enquiry*\n"
        f"─────────────────\n"
        f"👤 {user_name} ({user_mobile})\n"
        f"💬 {message or 'Interested in bulk document processing.'}\n"
        f"─────────────────\n"
        f"Reply directly to discuss pricing."
    )
    _send(BULK_ENQUIRY_NUMBER, msg)

def _send(to, body):
    if not to or not to.startswith("whatsapp:"):
        print(f"[WhatsApp] Skipped — invalid number: {to}")
        return
    try:
        client = _client()
        msg = client.messages.create(from_=TWILIO_WHATSAPP_FROM, to=to, body=body)
        print(f"[WhatsApp] Sent to {to} — SID: {msg.sid}")
    except Exception as e:
        print(f"[WhatsApp] Failed: {e}")
