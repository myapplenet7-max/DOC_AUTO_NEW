from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from datetime import datetime


def _set_telugu_capable_font(doc: Document):
    """Set the document's Normal style to a font that has Telugu glyph
    coverage. 'Nirmala UI' ships with Windows/Office and renders both Latin
    and Telugu correctly; without this, some viewers fall back to a font
    with no Telugu glyphs and Telugu text shows as boxes."""
    style = doc.styles["Normal"]
    style.font.name = "Nirmala UI"
    # python-docx requires setting the East Asian/complex-script font
    # separately via the underlying XML, or Word may ignore the font name
    # for non-Latin runs.
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = rpr.makeelement(qn("w:rFonts"), {})
        rpr.append(rfonts)
    rfonts.set(qn("w:ascii"), "Nirmala UI")
    rfonts.set(qn("w:hAnsi"), "Nirmala UI")
    rfonts.set(qn("w:cs"), "Nirmala UI")


def generate_docx(fields: dict, output_path: str):
    """
    Generate a formatted DOCX from extracted fields.
    Customize sections below for Sale Deed, PAN form, etc.
    """
    doc = Document()
    _set_telugu_capable_font(doc)

    # ── Title ──────────────────────────────────────────
    title = doc.add_heading("DOCUMENT RECORD", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph(f"Generated on: {datetime.now().strftime('%d-%m-%Y %H:%M')}")
    doc.add_paragraph("")

    # ── Applicant Details ──────────────────────────────
    doc.add_heading("Applicant Details", level=2)
    _add_field_table(doc, {
        "Full Name":        fields.get("full_name", ""),
        "Father's Name":    fields.get("father_name", ""),
        "Date of Birth":    fields.get("date_of_birth", ""),
        "Aadhaar Number":   fields.get("aadhar_number", ""),
        "PAN Number":       fields.get("pan_number", ""),
        "Mobile":           fields.get("mobile", ""),
        "Email":            fields.get("email", ""),
        "Pincode":          fields.get("pincode", ""),
    })

    # ── Property Details (for deeds) ───────────────────
    if fields.get("survey_number") or fields.get("sale_amount") or fields.get("village"):
        doc.add_paragraph("")
        doc.add_heading("Property Details", level=2)
        _add_field_table(doc, {
            "Survey Number":        fields.get("survey_number", ""),
            "Village":              fields.get("village", ""),
            "Sale Amount (₹)":      fields.get("sale_amount", ""),
            "Registration Date":    fields.get("registration_date", ""),
        })

    # ── Address ────────────────────────────────────────
    if fields.get("address"):
        doc.add_paragraph("")
        doc.add_heading("Address", level=2)
        doc.add_paragraph(fields["address"])

    # ── Raw OCR Text (collapsible reference) ──────────
    doc.add_paragraph("")
    doc.add_heading("Raw Extracted Text", level=3)
    p = doc.add_paragraph(fields.get("raw_text", ""))
    p.runs[0].font.size = Pt(8)

    doc.save(output_path)


def _add_field_table(doc: Document, data: dict):
    """Render a two-column label/value table."""
    table = doc.add_table(rows=0, cols=2)
    table.style = "Table Grid"

    for label, value in data.items():
        if not value:
            continue
        row = table.add_row().cells
        row[0].text = label
        row[1].text = str(value)
        # Bold the label
        for para in row[0].paragraphs:
            for run in para.runs:
                run.bold = True
