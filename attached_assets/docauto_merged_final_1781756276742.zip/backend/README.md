# DocAuto FastAPI Backend

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your Supabase PostgreSQL URL and a strong SECRET_KEY
```

## Run

```bash
uvicorn main:app --reload --port 8000
```

## API Docs

Open http://localhost:8000/docs for the interactive Swagger UI.

## Folder Structure

```
backend/
├── main.py               # App entry point
├── database.py           # SQLAlchemy engine + session
├── models.py             # DB tables: User, Document, Payment
├── schemas.py            # Pydantic request/response models
├── auth_utils.py         # JWT + password hashing
├── requirements.txt
├── routers/
│   ├── auth.py           # /api/auth/register, /login, /me
│   ├── documents.py      # /api/documents/upload, /generate, /download
│   ├── payments.py       # /api/payments/submit, /my
│   └── admin.py          # /api/admin/payments, /users, /stats
└── services/
    ├── ocr_service.py    # EasyOCR + pdfplumber + field detection
    └── docx_service.py   # python-docx DOCX generation
```

## Key Flows

### User Flow
1. POST /api/auth/register → get JWT token
2. POST /api/payments/submit (form + screenshot) → pending payment
3. Admin approves → wallet credited
4. POST /api/documents/upload (file) → OCR + field detection (costs ₹10)
5. PUT /api/documents/{id}/fields → edit extracted fields
6. POST /api/documents/{id}/generate → create DOCX
7. GET /api/documents/{id}/download → download DOCX

### Admin Flow
1. GET /api/admin/payments/pending → see pending payments
2. PUT /api/admin/payments/{id}/review → approve/reject
3. GET /api/admin/stats → dashboard numbers

## Telugu OCR

To enable Telugu OCR, edit `services/ocr_service.py`:
```python
reader = easyocr.Reader(['en', 'te'], gpu=False)
```

Note: Telugu model download is ~500MB on first run.
