import re
import os

# ── OCR reader cache ──────────────────────────────────────────────────────
# EasyOCR's Reader() loads model weights from disk on every instantiation,
# which takes several seconds. Re-creating it on every upload request would
# make each document take noticeably longer than necessary. We initialize
# it once per process and reuse it.
_READER = None
_READER_LANGS = ["en", "te"]  # English + Telugu


def _get_reader():
    global _READER
    if _READER is None:
        import easyocr
        # gpu=False is correct for most Replit/small-VPS deployments that
        # don't have a CUDA GPU available. Set gpu=True only if you've
        # confirmed a GPU is present and torch was installed with CUDA support.
        _READER = easyocr.Reader(_READER_LANGS, gpu=False)
    return _READER


def extract_text(file_path: str) -> str:
    """
    Extract text from image or PDF using EasyOCR (English + Telugu).
    Falls back to pdfplumber for PDF files that have a text layer; if a PDF
    is a scanned image with no text layer, pdfplumber will return nothing
    and the document should be re-uploaded as an image instead for now.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        text = _extract_from_pdf(file_path)
        # Scanned PDFs with no embedded text layer return empty/whitespace.
        # Fall back to rendering pages as images and running OCR on those.
        if text and text.strip():
            return text
        return _extract_from_scanned_pdf(file_path)
    else:
        return _extract_from_image(file_path)


def _extract_from_image(file_path: str) -> str:
    try:
        reader = _get_reader()
        results = reader.readtext(file_path, detail=0, paragraph=True)
        return "\n".join(results)
    except Exception as e:
        return f"OCR error: {str(e)}"


def _extract_from_pdf(file_path: str) -> str:
    try:
        import pdfplumber
        text_parts = []
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)
        return "\n".join(text_parts)
    except Exception as e:
        return f"PDF extraction error: {str(e)}"


def _extract_from_scanned_pdf(file_path: str) -> str:
    """Render each PDF page to an image and OCR it. Used when a PDF has
    no embedded text layer (i.e. it's a scan, not a digitally generated PDF)."""
    try:
        from pdf2image import convert_from_path
        pages = convert_from_path(file_path, dpi=300)
        reader = _get_reader()
        text_parts = []
        for page_image in pages:
            import numpy as np
            results = reader.readtext(np.array(page_image), detail=0, paragraph=True)
            text_parts.append("\n".join(results))
        return "\n".join(text_parts)
    except Exception as e:
        return f"Scanned PDF OCR error: {str(e)}"


def detect_fields(raw_text: str) -> dict:
    """
    Detect common Indian document fields from OCR text.
    Supports English and Telugu anchor keywords, since source documents may
    be in either language or mixed. Returns a dict of field_name -> value.
    """
    fields = {
        "full_name": "",
        "father_name": "",
        "date_of_birth": "",
        "aadhar_number": "",
        "pan_number": "",
        "mobile": "",
        "email": "",
        "address": "",
        "pincode": "",
        "survey_number": "",
        "village": "",
        "sale_amount": "",
        "registration_date": "",
        "raw_text": raw_text,
    }

    # Each field maps to a list of anchor keywords in English and Telugu.
    # Telugu anchors are matched against the raw (non-lowercased) line,
    # since Telugu script has no case-folding and lower() is a no-op for it.
    ANCHORS = {
        "full_name":    ["name:", "full name", "applicant name", "పేరు"],
        "father_name":  ["father", "s/o", "d/o", "w/o", "తండ్రి పేరు", "భర్త పేరు"],
        "survey_number": ["survey", "sy.no", "సర్వే నంబర్", "సర్వే నం"],
        "village":      ["village", "గ్రామం", "ఊరు"],
        "address":      ["address:", "చిరునామా"],
    }

    lines = raw_text.split("\n")

    for line in lines:
        line_lower = line.lower()

        # Full name
        if any(k in line_lower or k in line for k in ANCHORS["full_name"]):
            fields["full_name"] = _after_separator(line)

        # Father name
        if any(k in line_lower or k in line for k in ANCHORS["father_name"]):
            fields["father_name"] = _after_separator(line)

        # Village
        if any(k in line_lower or k in line for k in ANCHORS["village"]):
            fields["village"] = _after_separator(line)

        # Address
        if any(k in line_lower or k in line for k in ANCHORS["address"]):
            fields["address"] = _after_separator(line)

        # Date of birth
        dob_match = re.search(r'\b(\d{2}[\/\-]\d{2}[\/\-]\d{4})\b', line)
        if dob_match and not fields["date_of_birth"]:
            fields["date_of_birth"] = dob_match.group(1)

        # Aadhaar (12 digits, possibly spaced in groups of 4)
        aadhaar_match = re.search(r'\b(\d{4}\s?\d{4}\s?\d{4})\b', line)
        if aadhaar_match and not fields["aadhar_number"]:
            fields["aadhar_number"] = aadhaar_match.group(1).replace(" ", "")

        # PAN (ABCDE1234F pattern)
        pan_match = re.search(r'\b([A-Z]{5}[0-9]{4}[A-Z])\b', line)
        if pan_match and not fields["pan_number"]:
            fields["pan_number"] = pan_match.group(1)

        # Mobile (10 digits starting with 6-9)
        mobile_match = re.search(r'\b([6-9]\d{9})\b', line)
        if mobile_match and not fields["mobile"]:
            fields["mobile"] = mobile_match.group(1)

        # Email
        email_match = re.search(r'[\w\.\-]+@[\w\.\-]+\.\w+', line)
        if email_match and not fields["email"]:
            fields["email"] = email_match.group(0)

        # Pincode (6 digits)
        pin_match = re.search(r'\b(\d{6})\b', line)
        if pin_match and not fields["pincode"]:
            fields["pincode"] = pin_match.group(1)

        # Survey number
        if any(k in line_lower or k in line for k in ANCHORS["survey_number"]):
            fields["survey_number"] = _after_separator(line)

        # Amount (Rs./₹ followed by digits, or రూ. for Telugu rupee abbreviation)
        amount_match = re.search(r'(?:rs\.?|₹|రూ\.?)\s*([\d,]+)', line, re.IGNORECASE)
        if amount_match and not fields["sale_amount"]:
            fields["sale_amount"] = amount_match.group(1)

    return fields


def _after_separator(line: str) -> str:
    """Return text after the first colon or Telugu-style separator, stripped.
    Telugu government forms sometimes use ':' the same way English ones do,
    so this still works for mixed-language lines."""
    if ":" in line:
        return line.split(":", 1)[1].strip()
    return line.strip()
