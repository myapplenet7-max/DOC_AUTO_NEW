# DocAuto — Merged Build Notes

This folder merges your five zips (`docauto_backend-1`, `docauto_frontend`,
`docauto_whatsapp_update`, `docauto_credits_update`, `docauto_screenshot_update`)
into one consistent codebase, using each file's internal timestamp to decide
which version is newest where the same file appeared more than once.

## Merge order applied (oldest → newest)
1. `docauto_backend-1` + `docauto_frontend` — base backend and frontend
2. `docauto_whatsapp_update` — adds `whatsapp_service.py`, wires it into payments/admin
3. `docauto_credits_update` — credit-pack system, updated models/schemas/App.jsx
4. `docauto_screenshot_update` — latest `admin.py` and `App.jsx` (adds `AdminPage.jsx`)

Files that existed in multiple zips (`admin.py`, `payments.py`, `App.jsx`,
`models.py`, `schemas.py`, `documents.py`, `auth.py`, `requirements.txt`,
`whatsapp_service.py`) now reflect the latest version only.

## End-to-end workflow already implemented
The upload → OCR → editable form → generate → download flow already exists
across these files — it didn't need to be built from scratch:

- `frontend/src/App.jsx` → `UploadPage` component: file picker, calls
  `POST /documents/upload`, renders editable fields, calls
  `PUT /documents/{id}/fields` then `POST /documents/{id}/generate`,
  then links to `GET /documents/{id}/download`.
- `backend/routers/documents.py` → the four endpoints above.
- `backend/services/ocr_service.py` → `extract_text()` (EasyOCR for images,
  pdfplumber for PDFs) + `detect_fields()` (regex-based field detection).
- `backend/services/docx_service.py` → `generate_docx()` renders the final
  Word document from the edited fields.

## Bug fixed in this merge
`routers/documents.py` — the download endpoint used
`Depends(get_current_user)`, which only reads the `Authorization: Bearer`
header. The frontend's download button opens the file via
`window.open(...?token=...)`, which **cannot** set custom headers, so every
download was failing with 401.

Fixed by adding a dedicated query-param token check (`_get_user_from_query_token`)
used only on the download route, since that's the one endpoint reached via a
plain link rather than an authenticated `fetch()` call.

## Telugu OCR support (added)

`services/ocr_service.py` now runs EasyOCR with `["en", "te"]` instead of
`["en"]` only. Three related changes came with this, since just adding the
language code isn't enough on its own:

1. **Reader caching.** EasyOCR's `Reader()` loads model weights from disk
   on every call, which is slow. It's now created once per process (module-
   level cache) instead of once per upload request.
2. **Telugu field-detection anchors.** OCR finding Telugu text was only half
   the problem — `detect_fields()` was still only matching English anchor
   keywords like `"name:"` or `"survey"`. Added Telugu anchors (పేరు,
   తండ్రి పేరు, సర్వే నంబర్, గ్రామం, చిరునామా) so fields actually populate
   on Telugu-language documents, not just English ones. Also added a new
   `village` field (గ్రామం), which the original extraction didn't capture
   at all but is common on Telangana/AP revenue and land documents. Wired
   `village` into the generated DOCX (`docx_service.py`) and the frontend
   form labels (`App.jsx`) so it doesn't get silently dropped.
3. **Font for Telugu glyphs in the output DOCX.** `docx_service.py` now sets
   the document's Normal style to "Nirmala UI" (ships with Windows/Office,
   has full Telugu glyph coverage). Without this, some renderers fall back
   to a font with no Telugu glyphs and the generated Word doc shows boxes
   instead of Telugu text.
4. **Scanned-PDF fallback.** If a PDF has no embedded text layer (i.e. it's
   a scanned image saved as PDF, common with phone scanning apps),
   `pdfplumber` returns nothing. Added `_extract_from_scanned_pdf()`, which
   renders each page to an image via `pdf2image` and runs it through the
   same cached EasyOCR reader.

### New dependency requirements
- `pdf2image` (Python package) — added to `requirements.txt`.
- `poppler-utils` (**system** package, not pip) — `pdf2image` shells out to
  `pdftoppm`, so this must be installed at the OS level:
  `apt-get install poppler-utils` (Debian/Ubuntu/most Replit images) or
  `pacman -S poppler` (Arch).
- `numpy` — added to `requirements.txt`, needed to pass rendered PDF pages
  into EasyOCR's `readtext()`.
- First-run network access — EasyOCR downloads the Telugu model weights
  (~50–100MB) the first time `_get_reader()` runs with `"te"` in the
  language list. Make sure the deployment environment has outbound network
  access at least once, or pre-download the models during your build step
  rather than at first request (otherwise your first user's upload will
  hang while the model downloads).

## Known follow-ups (not yet handled — flag if you want these built)
- No image-enhancement (deskew/threshold) step before OCR yet — accuracy on
  skewed phone-camera photos will be lower until that's added. This matters
  more for Telugu than English since OCR is generally less robust on
  non-Latin scripts when the source image is noisy or skewed.
- `requirements.txt` lacks an explicit CPU-only torch pin — `easyocr`
  depends on torch, and on a CPU-only deployment (most small Replit/VPS
  instances) you may want to pre-install the CPU build explicitly to avoid
  pulling the much larger CUDA build:
  `pip install torch --index-url https://download.pytorch.org/whl/cpu`
