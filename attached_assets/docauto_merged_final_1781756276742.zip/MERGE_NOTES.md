# DocAuto — Merged Build Notes

This folder merges your five zips (`docauto_backend-1`, `docauto_frontend`,
`docauto_whatsapp_update`, `docauto_credits_update`, `docauto_screenshot_update`)
into one consistent codebase, using each file's internal timestamp to decide
which version is newest where the same file appeared more than once.

## Merge order applied (oldest → newest)
1. `docauto_backend-1` + `docauto_frontend` — base backend and frontend
2. `docauto_whatsapp_update` — adds `whatsapp_service.py`, wires it into payments/admin
3. `docauto_credits_update` — credit-pack system, updated models/schemas/App.jsx
4. `docauto_screenshot_update` — latest `admin.py` and `App.jsx` (adds `AdminPage.jsx`)

Files that existed in multiple zips (`admin.py`, `payments.py`, `App.jsx`,
`models.py`, `schemas.py`, `documents.py`, `auth.py`, `requirements.txt`,
`whatsapp_service.py`) now reflect the latest version only.

## End-to-end workflow already implemented
The upload → OCR → editable form → generate → download flow you asked about
already exists across these files — it didn't need to be built from scratch:

- `frontend/src/App.jsx` → `UploadPage` component: file picker, calls
  `POST /documents/upload`, renders editable fields, calls
  `PUT /documents/{id}/fields` then `POST /documents/{id}/generate`,
  then links to `GET /documents/{id}/download`.
- `backend/routers/documents.py` → the four endpoints above.
- `backend/services/ocr_service.py` → `extract_text()` (EasyOCR for images,
  pdfplumber for PDFs) + `detect_fields()` (regex-based field detection:
  name, father's name, DOB, Aadhaar, PAN, mobile, email, pincode, survey
  number, sale amount).
- `backend/services/docx_service.py` → `generate_docx()` renders the final
  Word document from the edited fields.

## Bug fixed in this merge
`routers/documents.py` — the download endpoint used
`Depends(get_current_user)`, which only reads the `Authorization: Bearer`
header. The frontend's download button opens the file via
`window.open(...?token=...)`, which **cannot** set custom headers, so every
download was failing with 401.

Fixed by adding a dedicated query-param token check (`_get_user_from_query_token`)
used only on the download route, since that's the one endpoint reached via a
plain link rather than an authenticated `fetch()` call.

## Known follow-ups (not yet handled — flag if you want these built)
- Telugu OCR: `ocr_service.py` currently runs EasyOCR with `['en']` only.
  Switch to `['en', 'te']` once you've installed the Telugu language model
  weights (EasyOCR downloads them on first use).
- `requirements.txt` lacks `easyocr`'s torch dependency pin — first deploy
  may pull a large CPU build of torch; consider pinning `torch==2.x+cpu` if
  deploying to a small Replit/VPS instance.
- No image-enhancement (deskew/threshold) step before OCR yet — accuracy on
  skewed phone-camera photos will be lower until that's added.
