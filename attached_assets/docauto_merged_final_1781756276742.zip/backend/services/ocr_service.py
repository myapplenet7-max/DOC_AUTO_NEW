import re
import os

def extract_text(file_path: str) -> str:
    """
    Extract text from image or PDF using EasyOCR.
    Falls back to pdfplumber for PDF files.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        return _extract_from_pdf(file_path)
    else:
        return _extract_from_image(file_path)


def _extract_from_image(file_path: str) -> str:
    try:
        import easyocr
        # Add 'te' for Telugu support: ['en', 'te']
        reader = easyocr.Reader(['en'], gpu=False)
        results = reader.readtext(file_path, detail=0)
        return "\n".join(results)
    except Exception as e:
        return f"OCR error: {str(e)}"


def _extract_from_pdf(file_path: str) -> str:
    try:
        import pdfplumber
        text_parts = []
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)
        return "\n".join(text_parts)
    except Exception as e:
        return f"PDF extraction error: {str(e)}"


def detect_fields(raw_text: str) -> dict:
    """
    Detect common Indian document fields from OCR text.
    Returns a dict of field_name -> detected_value.
    """
    fields = {
        "full_name": "",
        "father_name": "",
        "date_of_birth": "",
        "aadhar_number": "",
        "pan_number": "",
        "mobile": "",
        "email": "",
        "address": "",
        "pincode": "",
        "survey_number": "",
        "sale_amount": "",
        "registration_date": "",
        "raw_text": raw_text,
    }

    lines = raw_text.split("\n")

    for line in lines:
        line_lower = line.lower()

        # Full name
        if any(k in line_lower for k in ["name:", "full name", "applicant name"]):
            fields["full_name"] = _after_colon(line)

        # Father name
        if any(k in line_lower for k in ["father", "s/o", "d/o", "w/o"]):
            fields["father_name"] = _after_colon(line)

        # Date of birth
        dob_match = re.search(r'\b(\d{2}[\/\-]\d{2}[\/\-]\d{4})\b', line)
        if dob_match and not fields["date_of_birth"]:
            fields["date_of_birth"] = dob_match.group(1)

        # Aadhaar (12 digits, possibly spaced in groups of 4)
        aadhaar_match = re.search(r'\b(\d{4}\s?\d{4}\s?\d{4})\b', line)
        if aadhaar_match and not fields["aadhar_number"]:
            fields["aadhar_number"] = aadhaar_match.group(1).replace(" ", "")

        # PAN (ABCDE1234F pattern)
        pan_match = re.search(r'\b([A-Z]{5}[0-9]{4}[A-Z])\b', line)
        if pan_match and not fields["pan_number"]:
            fields["pan_number"] = pan_match.group(1)

        # Mobile (10 digits starting with 6-9)
        mobile_match = re.search(r'\b([6-9]\d{9})\b', line)
        if mobile_match and not fields["mobile"]:
            fields["mobile"] = mobile_match.group(1)

        # Email
        email_match = re.search(r'[\w\.\-]+@[\w\.\-]+\.\w+', line)
        if email_match and not fields["email"]:
            fields["email"] = email_match.group(0)

        # Pincode (6 digits)
        pin_match = re.search(r'\b(\d{6})\b', line)
        if pin_match and not fields["pincode"]:
            fields["pincode"] = pin_match.group(1)

        # Survey number
        if "survey" in line_lower or "sy.no" in line_lower:
            fields["survey_number"] = _after_colon(line)

        # Amount
        amount_match = re.search(r'(?:rs\.?|₹)\s*([\d,]+)', line_lower)
        if amount_match and not fields["sale_amount"]:
            fields["sale_amount"] = amount_match.group(1)

    return fields


def _after_colon(line: str) -> str:
    """Return text after the first colon, stripped."""
    if ":" in line:
        return line.split(":", 1)[1].strip()
    return line.strip()
