# DocAuto Frontend

React + Tailwind CSS frontend for the DocAuto document automation platform.

## Setup

```bash
npm install
npm run dev       # Development at http://localhost:5173
npm run build     # Build for production
```

## Deploy to Vercel

```bash
npm install -g vercel
vercel --prod
```

Set environment variable in Vercel dashboard:
- `VITE_API_URL` = your backend URL (e.g. https://your-backend.replit.app/api)

Then update `const API = ...` in `src/App.jsx` to:
```js
const API = import.meta.env.VITE_API_URL || "http://localhost:8000/api";
```

## Pages

| Page | Route (SPA state) | Description |
|------|-------------------|-------------|
| Login/Register | Default (no auth) | Mobile + password auth |
| Dashboard | dashboard | Wallet balance + quick actions |
| Upload | upload | Drag-drop upload → OCR → edit fields → DOCX |
| Documents | documents | History of all processed documents |
| Add Funds | wallet | UPI screenshot submission + payment history |
| Admin Panel | admin | Approve/reject payments, user list, stats |

## Making yourself Admin

After registering, run this SQL on Supabase:
```sql
UPDATE users SET role = 'admin' WHERE mobile = 'your-mobile-number';
```
